<?php

namespace Monetha\Consts;

class ApiType
{
    const PROD = 'https://api.monetha.io/mth-gateway/';
    const TEST = 'https://api-sandbox.monetha.io/mth-gateway/';
}
